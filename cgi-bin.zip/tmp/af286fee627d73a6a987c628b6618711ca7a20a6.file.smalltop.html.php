<?php /* Smarty version Smarty-3.0.8, created on 2019-01-25 08:00:02
         compiled from "/home/sexguestbook/public_html/tpl/admin/index/smalltop.html" */ ?>
<?php /*%%SmartyHeaderCode:14177746645c4ac2021dcdb4-75236483%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'af286fee627d73a6a987c628b6618711ca7a20a6' => 
    array (
      0 => '/home/sexguestbook/public_html/tpl/admin/index/smalltop.html',
      1 => 1548402385,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14177746645c4ac2021dcdb4-75236483',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<a href="javascript:history.go(-1)"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> 返回上一页</a> &nbsp;&nbsp;<a href="javascript:location.reload()"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span> 刷新</a>