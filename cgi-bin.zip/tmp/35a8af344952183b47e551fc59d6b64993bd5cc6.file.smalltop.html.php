<?php /* Smarty version Smarty-3.0.8, created on 2019-01-25 15:09:06
         compiled from "/Users/rookie/Code/getbook/tpl/admin/index/smalltop.html" */ ?>
<?php /*%%SmartyHeaderCode:13996845705c4ab6125940f6-21614003%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35a8af344952183b47e551fc59d6b64993bd5cc6' => 
    array (
      0 => '/Users/rookie/Code/getbook/tpl/admin/index/smalltop.html',
      1 => 1446197984,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13996845705c4ab6125940f6-21614003',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<a href="javascript:history.go(-1)"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> 返回上一页</a> &nbsp;&nbsp;<a href="javascript:location.reload()"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span> 刷新</a>