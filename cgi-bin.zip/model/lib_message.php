<?php
class lib_message extends spModel
{
  var $pk = "id"; // 数据表的主键
  var $table = "message"; // 数据表的名称
}