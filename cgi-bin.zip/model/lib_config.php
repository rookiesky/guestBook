<?php
class lib_config extends spModel
{
  var $pk = "id"; // 数据表的主键
  var $table = "mconfig"; // 数据表的名称
}