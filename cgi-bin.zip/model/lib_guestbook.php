<?php
class lib_guestbook extends spModel
{
  var $pk = "id"; // 数据表的主键
  var $table = "guestbook"; // 数据表的名称
}