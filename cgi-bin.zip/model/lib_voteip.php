<?php
class lib_voteip extends spModel
{
  var $pk = "id"; // 数据表的主键
  var $table = "voteip"; // 数据表的名称
}