<?php
$host='localhost';
$login='sexguest_admin';
$password='1Q1ZwU?SPEtQ';
$database='sexguest_book';
$prefix='sy_';
?>